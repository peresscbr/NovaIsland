# Nova Island

Ilha dinâmica para Android, leve e sem anúncios, pensada para a câmera frontal (punch-hole) dos Motorola.

- **Notificações** em forma de ilha (toque abre o app; deslize para cima dispensa).
- **Controles de mídia** (anterior, play/pause, próxima) com capa e título.
- **Aviso ao conectar o carregador.**
- **Posicionamento automático** pelo recorte real da câmera + ajuste fino por controles.
- Sem INTERNET, sem Firebase, sem anúncios. Só 2 permissões extras (bateria e visibilidade de apps).

Requisitos: Android 11 (API 30) ou superior.

## Gerar o APK (sem instalar nada)

1. Crie um repositório vazio no GitHub e envie o conteúdo desta pasta.
2. Aba **Actions** → **Build APK** → **Run workflow** (também roda sozinho a cada push).
3. Ao terminar (~5 min), baixe **NovaIsland-apk** em *Artifacts*, extraia o zip e instale o `app-release.apk`.

## Gerar pelo Android Studio

Abra a pasta no Android Studio (Ladybug ou mais novo) → **Build > Build APK(s)**,
ou na linha de comando, com Gradle 8.9 e JDK 17: `gradle assembleRelease`.
O APK sai em `app/build/outputs/apk/release/app-release.apk` (assinado com a chave de debug, instala direto).

## Primeiro uso no Motorola

1. Instale o APK e abra o app.
2. **Acessibilidade → Ativar.** Se o botão do serviço estiver cinza (Android 13+): *Informações do app → ⋮ → Permitir configurações restritas*.
3. **Notificações e mídia → Ativar** (permite ler notificações e a música tocando).
4. **Bateria → Ajustar**, e em Configurações > Apps > Nova Island > Bateria escolha *Sem restrições*.
5. Nos apps recentes, toque no ícone do app e escolha *Bloquear*.
6. Toque em **Testar a ilha**.
