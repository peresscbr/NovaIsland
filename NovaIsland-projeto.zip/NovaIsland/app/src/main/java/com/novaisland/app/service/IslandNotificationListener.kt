package com.novaisland.app.service

import android.app.Notification
import android.app.NotificationManager
import android.content.ComponentName
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.PowerManager
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import com.novaisland.app.core.IslandBus
import com.novaisland.app.core.MediaInfo
import com.novaisland.app.core.NotificationInfo
import com.novaisland.app.data.NotificationHistory
import com.novaisland.app.data.Prefs

class IslandNotificationListener : NotificationListenerService() {

    private var sessionManager: MediaSessionManager? = null
    private var current: MediaController? = null
    private val lastSignature = HashMap<String, String>()

    private val sessionsListener =
        MediaSessionManager.OnActiveSessionsChangedListener { controllers -> pickController(controllers) }

    private val controllerCallback = object : MediaController.Callback() {
        override fun onPlaybackStateChanged(state: PlaybackState?) {
            publishMedia()
        }

        override fun onMetadataChanged(metadata: MediaMetadata?) {
            publishMedia()
        }

        override fun onSessionDestroyed() {
            refreshSessions()
        }
    }

    private fun me() = ComponentName(this, IslandNotificationListener::class.java)

    // ---------------------------------------------------------------- mídia

    override fun onListenerConnected() {
        super.onListenerConnected()
        sessionManager = getSystemService(MediaSessionManager::class.java)
        try {
            sessionManager?.addOnActiveSessionsChangedListener(sessionsListener, me())
        } catch (_: SecurityException) {
        }
        refreshSessions()
    }

    override fun onListenerDisconnected() {
        teardownMedia()
        super.onListenerDisconnected()
    }

    override fun onDestroy() {
        teardownMedia()
        super.onDestroy()
    }

    private fun teardownMedia() {
        try {
            sessionManager?.removeOnActiveSessionsChangedListener(sessionsListener)
        } catch (_: Exception) {
        }
        try {
            current?.unregisterCallback(controllerCallback)
        } catch (_: Exception) {
        }
        current = null
        IslandBus.postMedia(null)
    }

    private fun refreshSessions() {
        val list = try {
            sessionManager?.getActiveSessions(me())
        } catch (_: SecurityException) {
            null
        }
        pickController(list)
    }

    private fun pickController(list: List<MediaController>?) {
        val best = list?.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING }
            ?: list?.firstOrNull { it.metadata != null }
        if (best?.sessionToken != current?.sessionToken) {
            try {
                current?.unregisterCallback(controllerCallback)
            } catch (_: Exception) {
            }
            current = best
            best?.registerCallback(controllerCallback)
        }
        publishMedia()
    }

    private fun publishMedia() {
        val c = current
        if (c == null) {
            IslandBus.postMedia(null)
            return
        }
        val md = c.metadata
        val title = md?.getString(MediaMetadata.METADATA_KEY_TITLE)
            ?: md?.getString(MediaMetadata.METADATA_KEY_DISPLAY_TITLE)
            ?: ""
        if (md == null || title.isBlank()) {
            IslandBus.postMedia(null)
            return
        }
        val artist = md.getString(MediaMetadata.METADATA_KEY_ARTIST)
            ?: md.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST)
            ?: md.getString(MediaMetadata.METADATA_KEY_DISPLAY_SUBTITLE)
            ?: ""
        val art = md.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
            ?: md.getBitmap(MediaMetadata.METADATA_KEY_ART)
            ?: md.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON)
        val playing = c.playbackState?.state == PlaybackState.STATE_PLAYING
        IslandBus.postMedia(MediaInfo(title, artist, art, playing, c))
    }

    // --------------------------------------------------------- notificações

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        if (sbn == null) return
        try {
            handle(sbn)
        } catch (_: Throwable) {
            // Uma notificação mal formada nunca deve derrubar o serviço.
        }
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification?) {
        if (sbn != null) lastSignature.remove(sbn.key)
    }

    private fun handle(sbn: StatusBarNotification) {
        if (sbn.packageName == packageName) return
        val n = sbn.notification ?: return

        val f = n.flags
        if (f and Notification.FLAG_GROUP_SUMMARY != 0) return
        if (f and Notification.FLAG_ONGOING_EVENT != 0) return
        if (f and Notification.FLAG_FOREGROUND_SERVICE != 0) return
        when (n.category) {
            Notification.CATEGORY_TRANSPORT,
            Notification.CATEGORY_PROGRESS,
            Notification.CATEGORY_SERVICE,
            Notification.CATEGORY_SYSTEM,
            Notification.CATEGORY_CALL,
            Notification.CATEGORY_ALARM,
            Notification.CATEGORY_STATUS -> return
        }
        // Chamadas e alarmes (tela cheia) continuam sendo do sistema.
        if (n.fullScreenIntent != null) return

        // Notificações silenciosas não devem "pular" na tela.
        val ranking = Ranking()
        if (currentRanking.getRanking(sbn.key, ranking) &&
            ranking.importance < NotificationManager.IMPORTANCE_DEFAULT
        ) return

        val extras = n.extras
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val text = (extras.getCharSequence(Notification.EXTRA_TEXT)
            ?: extras.getCharSequence(Notification.EXTRA_BIG_TEXT))?.toString().orEmpty()
        if (title.isBlank() && text.isBlank()) return

        // Apps atualizam a mesma notificação várias vezes: só mostra se o conteúdo mudou.
        val signature = "$title|$text"
        if (lastSignature[sbn.key] == signature) return
        if (lastSignature.size > 200) lastSignature.clear()
        lastSignature[sbn.key] = signature

        val pm = packageManager
        val appName = try {
            pm.getApplicationLabel(pm.getApplicationInfo(sbn.packageName, 0)).toString()
        } catch (_: Exception) {
            sbn.packageName
        }
        val icon = try {
            n.getLargeIcon()?.loadDrawable(this) ?: pm.getApplicationIcon(sbn.packageName)
        } catch (_: Exception) {
            null
        }

        IslandBus.postNotification(
            NotificationInfo(sbn.key, sbn.packageName, appName, title, text, icon, n.contentIntent)
        )

        // Substitui a notificação do sistema: só quando a ilha realmente vai mostrá-la
        // (tela ligada, ilha ativa e visível) e a notificação pode ser dispensada pelo usuário.
        val power = getSystemService(PowerManager::class.java)
        val replace = Prefs.of(this).getBoolean(Prefs.REPLACE_SYSTEM, true) &&
            IslandBus.canShowNotifications &&
            power?.isInteractive == true &&
            sbn.isClearable
        if (replace) {
            NotificationHistory.add(
                this,
                NotificationHistory.Entry(
                    sbn.packageName, appName, title.ifBlank { appName }, text, System.currentTimeMillis()
                )
            )
            cancelNotification(sbn.key)
        }
    }
}
