package com.novaisland.app.ui

import android.graphics.Canvas
import android.graphics.ColorFilter
import android.graphics.LinearGradient
import android.graphics.Outline
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.RadialGradient
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.drawable.Drawable
import kotlin.math.max

/**
 * Fundo da ilha. Em repouso é preto puro (se funde com a câmera). Ao expandir, ganha o "vidro":
 * brilho em degradê, reflexo especular no topo e borda de luz fina, no estilo Liquid Glass.
 */
class GlassDrawable(density: Float) : Drawable() {

    private val base = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF000000.toInt() }
    private val gloss = Paint(Paint.ANTI_ALIAS_FLAG)
    private val sheen = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rim = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = max(1f, density)
    }
    private val rect = RectF()
    private val rimRect = RectF()

    var radius = 0f
        set(v) {
            field = v
            invalidateSelf()
        }

    /** 0 = preto puro (repouso), 1 = vidro completo (expandido). */
    var glass = 0f
        set(v) {
            field = v.coerceIn(0f, 1f)
            applyAlpha()
            invalidateSelf()
        }

    private fun applyAlpha() {
        val a = (glass * 255f).toInt()
        gloss.alpha = a
        sheen.alpha = a
        rim.alpha = a
    }

    override fun onBoundsChange(bounds: Rect) {
        rect.set(bounds)
        val half = rim.strokeWidth / 2f
        rimRect.set(rect.left + half, rect.top + half, rect.right - half, rect.bottom - half)
        gloss.shader = LinearGradient(
            0f, rect.top, 0f, rect.bottom, 0x24FFFFFF, 0x08FFFFFF, Shader.TileMode.CLAMP
        )
        sheen.shader = RadialGradient(
            rect.centerX(), rect.top, max(rect.width() * 0.6f, 1f),
            0x33FFFFFF, 0x00FFFFFF, Shader.TileMode.CLAMP
        )
        rim.shader = LinearGradient(
            0f, rect.top, 0f, rect.bottom, 0x66FFFFFF, 0x14FFFFFF, Shader.TileMode.CLAMP
        )
        applyAlpha()
    }

    override fun draw(canvas: Canvas) {
        if (rect.isEmpty) return
        canvas.drawRoundRect(rect, radius, radius, base)
        if (glass <= 0f) return
        canvas.drawRoundRect(rect, radius, radius, gloss)
        canvas.drawRoundRect(rect, radius, radius, sheen)
        val r = max(0f, radius - rim.strokeWidth / 2f)
        canvas.drawRoundRect(rimRect, r, r, rim)
    }

    override fun getOutline(outline: Outline) {
        outline.setRoundRect(bounds, radius)
    }

    override fun setAlpha(alpha: Int) = Unit

    override fun setColorFilter(colorFilter: ColorFilter?) = Unit

    @Suppress("DEPRECATION", "OVERRIDE_DEPRECATION")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}
