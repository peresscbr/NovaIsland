package com.novaisland.app.service

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent
import com.novaisland.app.core.IslandController

/**
 * Serviço de acessibilidade usado só como "âncora" para a janela TYPE_ACCESSIBILITY_OVERLAY.
 * Não lê nada da tela (canRetrieveWindowContent = false). Vantagens sobre SYSTEM_ALERT_WINDOW:
 * não exige serviço em primeiro plano e o sistema (incluindo o gerenciador de bateria da Motorola)
 * o mantém vivo com muito mais confiabilidade.
 */
class IslandAccessibilityService : AccessibilityService() {

    private var controller: IslandController? = null

    override fun onServiceConnected() {
        super.onServiceConnected()
        controller?.stop()
        controller = IslandController(this).also { it.start() }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) = Unit

    override fun onInterrupt() = Unit

    override fun onUnbind(intent: Intent?): Boolean {
        controller?.stop()
        controller = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        controller?.stop()
        controller = null
        super.onDestroy()
    }
}
