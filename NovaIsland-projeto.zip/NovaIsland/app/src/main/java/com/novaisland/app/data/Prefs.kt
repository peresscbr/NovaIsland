package com.novaisland.app.data

import android.content.Context
import android.content.SharedPreferences

object Prefs {
    private const val NAME = "nova_island_prefs"

    const val ENABLED = "enabled"
    const val IDLE_PILL = "idle_pill"
    const val SHOW_NOTIFICATIONS = "show_notifications"
    const val SHOW_MEDIA = "show_media"
    const val SHOW_CHARGING = "show_charging"
    const val HIDE_LANDSCAPE = "hide_landscape"
    const val HIDE_LOCKED = "hide_locked"
    const val HAPTIC = "haptic"
    const val REPLACE_SYSTEM = "replace_system"

    const val ADJ_W = "adj_w"
    const val ADJ_H = "adj_h"
    const val ADJ_X = "adj_x"
    const val ADJ_Y = "adj_y"

    val GEOMETRY_KEYS = setOf(ADJ_W, ADJ_H, ADJ_X, ADJ_Y)

    fun of(context: Context): SharedPreferences =
        context.applicationContext.getSharedPreferences(NAME, Context.MODE_PRIVATE)
}
