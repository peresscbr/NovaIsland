package com.novaisland.app

import android.content.ComponentName
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.NotificationManagerCompat
import com.google.android.material.button.MaterialButton
import com.google.android.material.materialswitch.MaterialSwitch
import com.google.android.material.slider.Slider
import com.novaisland.app.core.IslandBus
import com.novaisland.app.core.NotificationInfo
import com.novaisland.app.data.Prefs
import com.novaisland.app.service.IslandAccessibilityService

class MainActivity : AppCompatActivity() {

    private val prefs by lazy { Prefs.of(this) }

    private lateinit var statusAccessibility: TextView
    private lateinit var statusNotifications: TextView
    private lateinit var statusBattery: TextView
    private lateinit var btnAccessibility: MaterialButton
    private lateinit var btnNotifications: MaterialButton
    private lateinit var btnBattery: MaterialButton

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        statusAccessibility = findViewById(R.id.statusAccessibility)
        statusNotifications = findViewById(R.id.statusNotifications)
        statusBattery = findViewById(R.id.statusBattery)
        btnAccessibility = findViewById(R.id.btnAccessibility)
        btnNotifications = findViewById(R.id.btnNotifications)
        btnBattery = findViewById(R.id.btnBattery)

        btnAccessibility.setOnClickListener {
            safeStart(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        btnNotifications.setOnClickListener {
            safeStart(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }
        btnBattery.setOnClickListener {
            val direct = Intent(
                Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                Uri.parse("package:$packageName")
            )
            if (!safeStart(direct)) safeStart(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        }
        findViewById<MaterialButton>(R.id.btnAppInfo).setOnClickListener {
            safeStart(
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))
            )
        }
        findViewById<MaterialButton>(R.id.btnTest).setOnClickListener {
            IslandBus.postNotification(
                NotificationInfo(
                    key = "test",
                    pkg = packageName,
                    appName = getString(R.string.app_name),
                    title = getString(R.string.test_title),
                    text = getString(R.string.test_text),
                    icon = applicationInfo.loadIcon(packageManager),
                    intent = null
                )
            )
        }

        bindSwitch(R.id.swEnabled, Prefs.ENABLED)
        bindSwitch(R.id.swIdle, Prefs.IDLE_PILL)
        bindSwitch(R.id.swNotifications, Prefs.SHOW_NOTIFICATIONS)
        bindSwitch(R.id.swMedia, Prefs.SHOW_MEDIA)
        bindSwitch(R.id.swCharging, Prefs.SHOW_CHARGING)
        bindSwitch(R.id.swHideLandscape, Prefs.HIDE_LANDSCAPE)
        bindSwitch(R.id.swHideLocked, Prefs.HIDE_LOCKED)
        bindSwitch(R.id.swHaptic, Prefs.HAPTIC)

        bindSlider(R.id.slW, R.id.lblW, R.string.adj_width, Prefs.ADJ_W)
        bindSlider(R.id.slH, R.id.lblH, R.string.adj_height, Prefs.ADJ_H)
        bindSlider(R.id.slX, R.id.lblX, R.string.adj_x, Prefs.ADJ_X)
        bindSlider(R.id.slY, R.id.lblY, R.string.adj_y, Prefs.ADJ_Y)
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
    }

    private fun safeStart(intent: Intent): Boolean = try {
        startActivity(intent)
        true
    } catch (_: Exception) {
        false
    }

    private fun bindSwitch(id: Int, key: String) {
        val sw = findViewById<MaterialSwitch>(id)
        sw.isChecked = prefs.getBoolean(key, true)
        sw.setOnCheckedChangeListener { _, checked ->
            prefs.edit().putBoolean(key, checked).apply()
        }
    }

    private fun bindSlider(sliderId: Int, labelId: Int, labelRes: Int, key: String) {
        val slider = findViewById<Slider>(sliderId)
        val label = findViewById<TextView>(labelId)
        val value = prefs.getInt(key, 0)
            .toFloat()
            .coerceIn(slider.valueFrom, slider.valueTo)
        slider.value = value
        label.text = getString(labelRes, signed(value.toInt()))
        slider.addOnChangeListener { _, v, fromUser ->
            label.text = getString(labelRes, signed(v.toInt()))
            if (fromUser) prefs.edit().putInt(key, v.toInt()).apply()
        }
    }

    private fun signed(v: Int) = if (v > 0) "+$v" else v.toString()

    private fun refreshStatus() {
        val acc = isAccessibilityEnabled()
        val notif = NotificationManagerCompat.getEnabledListenerPackages(this).contains(packageName)
        val pm = getSystemService(PowerManager::class.java)
        val battery = pm?.isIgnoringBatteryOptimizations(packageName) == true

        render(statusAccessibility, btnAccessibility, acc, R.string.btn_activate)
        render(statusNotifications, btnNotifications, notif, R.string.btn_activate)
        render(statusBattery, btnBattery, battery, R.string.btn_fix)
    }

    private fun render(status: TextView, button: MaterialButton, ok: Boolean, actionLabel: Int) {
        status.setText(if (ok) R.string.status_on else R.string.status_off)
        button.setText(actionLabel)
        button.isEnabled = !ok
    }

    private fun isAccessibilityEnabled(): Boolean {
        val enabled = Settings.Secure.getString(
            contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        val me = ComponentName(this, IslandAccessibilityService::class.java)
        return enabled.split(':').any { ComponentName.unflattenFromString(it) == me }
    }
}
