package com.novaisland.app.core

import android.app.PendingIntent
import android.graphics.Bitmap
import android.graphics.drawable.Drawable
import android.media.session.MediaController
import android.os.Handler
import android.os.Looper
import java.util.concurrent.CopyOnWriteArraySet

enum class IslandMode { IDLE, NOTIFICATION, MEDIA, CHARGING }

class NotificationInfo(
    val key: String,
    val pkg: String,
    val appName: String,
    val title: String,
    val text: String,
    val icon: Drawable?,
    val intent: PendingIntent?
)

class MediaInfo(
    val title: String,
    val artist: String,
    val art: Bitmap?,
    val playing: Boolean,
    val controller: MediaController
) {
    val key: String get() = "${controller.packageName}|$title|$artist"
}

/** Ponte entre o NotificationListener (fonte dos dados) e o overlay (apresentação). Mesmo processo. */
object IslandBus {
    interface Listener {
        fun onNotification(info: NotificationInfo)
        fun onMedia(info: MediaInfo?)
    }

    private val main = Handler(Looper.getMainLooper())
    private val listeners = CopyOnWriteArraySet<Listener>()

    /**
     * Verdadeiro somente quando a ilha está na tela e pronta para exibir notificações.
     * O NotificationListener só remove uma notificação do sistema se isto for verdadeiro,
     * para nunca "engolir" uma notificação que a ilha não conseguiria mostrar.
     */
    @Volatile
    var canShowNotifications = false

    /** Última mídia conhecida. Só é lida/escrita na thread principal. */
    var media: MediaInfo? = null
        private set

    fun register(l: Listener) {
        listeners.add(l)
    }

    fun unregister(l: Listener) {
        listeners.remove(l)
    }

    fun postNotification(info: NotificationInfo) {
        main.post { listeners.forEach { it.onNotification(info) } }
    }

    fun postMedia(info: MediaInfo?) {
        main.post {
            media = info
            listeners.forEach { it.onMedia(info) }
        }
    }
}
