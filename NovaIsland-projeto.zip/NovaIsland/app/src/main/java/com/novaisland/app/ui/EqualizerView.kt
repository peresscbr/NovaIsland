package com.novaisland.app.ui

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.View
import android.view.animation.LinearInterpolator
import kotlin.math.PI
import kotlin.math.sin

/** Barrinhas animadas de áudio, exibidas ao lado direito da ilha compacta enquanto toca música. */
class EqualizerView(context: Context) : View(context) {

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
    private val bars = 4
    private var phase = 0f
    private var animator: ValueAnimator? = null

    fun start() {
        if (animator?.isRunning == true) return
        val a = ValueAnimator.ofFloat(0f, (2.0 * PI).toFloat())
        a.duration = 900L
        a.repeatCount = ValueAnimator.INFINITE
        a.interpolator = LinearInterpolator()
        a.addUpdateListener {
            phase = it.animatedValue as Float
            invalidate()
        }
        animator = a
        a.start()
    }

    fun stop() {
        animator?.cancel()
        animator = null
    }

    override fun onDetachedFromWindow() {
        stop()
        super.onDetachedFromWindow()
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return
        val gap = w * 0.12f
        val bw = (w - gap * (bars - 1)) / bars
        for (i in 0 until bars) {
            val f = 0.35f + 0.65f * ((sin(phase + i * 1.7f) + 1f) / 2f)
            val bh = h * f
            val x = i * (bw + gap)
            canvas.drawRoundRect(x, (h - bh) / 2f, x + bw, (h + bh) / 2f, bw / 2f, bw / 2f, paint)
        }
    }
}
