package com.novaisland.app.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Guarda as últimas notificações substituídas, para que nada se perca depois que a ilha some. */
object NotificationHistory {
    private const val FILE = "nova_island_history"
    private const val KEY = "items"
    private const val MAX = 40

    class Entry(val pkg: String, val app: String, val title: String, val text: String, val time: Long)

    private fun parse(raw: String?): JSONArray = try {
        if (raw.isNullOrEmpty()) JSONArray() else JSONArray(raw)
    } catch (_: Exception) {
        JSONArray()
    }

    @Synchronized
    fun add(ctx: Context, e: Entry) {
        val sp = ctx.applicationContext.getSharedPreferences(FILE, Context.MODE_PRIVATE)
        val old = parse(sp.getString(KEY, null))
        val out = JSONArray()
        out.put(
            JSONObject()
                .put("pkg", e.pkg).put("app", e.app)
                .put("title", e.title).put("text", e.text).put("time", e.time)
        )
        var i = 0
        while (i < old.length() && out.length() < MAX) {
            out.put(old.get(i))
            i++
        }
        sp.edit().putString(KEY, out.toString()).apply()
    }

    @Synchronized
    fun all(ctx: Context): List<Entry> {
        val sp = ctx.applicationContext.getSharedPreferences(FILE, Context.MODE_PRIVATE)
        val arr = parse(sp.getString(KEY, null))
        val list = ArrayList<Entry>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            list.add(
                Entry(
                    o.optString("pkg"), o.optString("app"),
                    o.optString("title"), o.optString("text"), o.optLong("time")
                )
            )
        }
        return list
    }

    @Synchronized
    fun clear(ctx: Context) {
        ctx.applicationContext.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit().remove(KEY).apply()
    }
}
