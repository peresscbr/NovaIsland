package com.novaisland.app.core

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.app.ActivityOptions
import android.app.KeyguardManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.graphics.PixelFormat
import android.graphics.Point
import android.graphics.Rect
import android.hardware.display.DisplayManager
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.Display
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.View
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import androidx.core.content.ContextCompat
import com.novaisland.app.data.Prefs
import com.novaisland.app.ui.IslandView
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Dono da janela de overlay. Calcula a geometria a partir do recorte real da tela (câmera),
 * anima entre os estados e reage às notificações, mídia e carregador.
 */
class IslandController(private val ctx: Context) :
    IslandBus.Listener, SharedPreferences.OnSharedPreferenceChangeListener {

    private class Geo(val cx: Float, val top: Float, val w: Float, val h: Float)

    private val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val dm = ctx.getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
    private val km = ctx.getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
    private val prefs = Prefs.of(ctx)
    private val main = Handler(Looper.getMainLooper())
    private val density = ctx.resources.displayMetrics.density
    private val view = IslandView(ctx)

    private val lp = WindowManager.LayoutParams().apply {
        type = WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY
        format = PixelFormat.TRANSLUCENT
        flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        gravity = Gravity.TOP or Gravity.START
        layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
        title = "NovaIsland"
    }

    private var attached = false
    private var started = false
    private var mode = IslandMode.IDLE
    private var lastMedia: MediaInfo? = null
    private var currentNotification: NotificationInfo? = null

    private var screenW = 0
    private var screenH = 0
    private var curW = 0f
    private var curH = 0f
    private var curCx = 0f
    private var curTop = 0f

    private var animator: ValueAnimator? = null
    private var autoMs = 0L
    private var previewing = false

    private val collapseRunnable = Runnable { collapse() }
    private val previewEnd = Runnable {
        previewing = false
        applyVisibility()
    }

    private val powerReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) {
            if (i?.action == Intent.ACTION_POWER_CONNECTED) onPowerConnected()
        }
    }

    private val displayListener = object : DisplayManager.DisplayListener {
        override fun onDisplayAdded(displayId: Int) = Unit
        override fun onDisplayRemoved(displayId: Int) = Unit
        override fun onDisplayChanged(displayId: Int) {
            if (displayId != Display.DEFAULT_DISPLAY) return
            val b = wm.currentWindowMetrics.bounds
            if (b.width() != screenW || b.height() != screenH) settle()
        }
    }

    // ------------------------------------------------------------ ciclo de vida

    fun start() {
        if (started) return
        started = true
        IslandBus.register(this)
        prefs.registerOnSharedPreferenceChangeListener(this)
        dm.registerDisplayListener(displayListener, main)
        ContextCompat.registerReceiver(
            ctx, powerReceiver, IntentFilter(Intent.ACTION_POWER_CONNECTED),
            ContextCompat.RECEIVER_EXPORTED
        )

        view.onInteraction = { if (mode != IslandMode.IDLE && autoMs > 0) schedule(max(autoMs, 4000L)) }
        view.onSwipeUp = { collapse() }
        view.setOnClickListener { onPillClick() }
        view.onPrev = { lastMedia?.controller?.transportControls?.skipToPrevious() }
        view.onNext = { lastMedia?.controller?.transportControls?.skipToNext() }
        view.onPlayPause = {
            val m = lastMedia
            if (m != null) {
                if (m.playing) m.controller.transportControls.pause() else m.controller.transportControls.play()
            }
        }

        lastMedia = IslandBus.media
        lastMedia?.let { view.bindMedia(it) }
        if (prefs.getBoolean(Prefs.ENABLED, true)) attach()
    }

    fun stop() {
        if (!started) return
        started = false
        main.removeCallbacksAndMessages(null)
        animator?.cancel()
        IslandBus.unregister(this)
        prefs.unregisterOnSharedPreferenceChangeListener(this)
        try {
            dm.unregisterDisplayListener(displayListener)
        } catch (_: Exception) {
        }
        try {
            ctx.unregisterReceiver(powerReceiver)
        } catch (_: Exception) {
        }
        detach()
    }

    private fun attach() {
        if (attached) return
        updateScreen()
        mode = IslandMode.IDLE
        val g = idleGeo()
        view.showMode(IslandMode.IDLE)
        view.setContentTopPadding(g.h.roundToInt())
        view.setContentAlpha(1f)
        applyGeometry(g.w, g.h, g.cx, g.top)
        try {
            wm.addView(view, lp)
            attached = true
        } catch (_: Exception) {
            attached = false
        }
        applyVisibility()
    }

    private fun detach() {
        animator?.cancel()
        main.removeCallbacks(collapseRunnable)
        if (attached) {
            try {
                wm.removeViewImmediate(view)
            } catch (_: Exception) {
            }
            attached = false
        }
        mode = IslandMode.IDLE
    }

    // ---------------------------------------------------------------- geometria

    private fun dp(v: Float) = v * density

    private fun updateScreen() {
        val b = wm.currentWindowMetrics.bounds
        screenW = b.width()
        screenH = b.height()
    }

    /** Retângulo real do recorte da câmera no topo da tela, ou null se o aparelho não tiver. */
    private fun cutoutRect(): Rect? {
        val d = dm.getDisplay(Display.DEFAULT_DISPLAY) ?: return null
        val r = d.cutout?.boundingRectTop ?: return null
        return if (r.isEmpty) null else r
    }

    private fun idleGeo(): Geo {
        val cut = cutoutRect()
        var cx: Float
        var top: Float
        var w: Float
        var h: Float
        if (cut != null) {
            val padX = dp(30f)
            val padY = dp(4f)
            top = max(0f, cut.top - padY)
            h = (cut.bottom + padY) - top
            w = cut.width() + padX * 2f
            cx = cut.exactCenterX()
        } else {
            w = dp(120f)
            h = dp(36f)
            top = dp(8f)
            cx = screenW / 2f
        }
        w = max(dp(36f), w + dp(prefs.getInt(Prefs.ADJ_W, 0).toFloat()))
        h = max(dp(14f), h + dp(prefs.getInt(Prefs.ADJ_H, 0).toFloat()))
        top = max(0f, top + dp(prefs.getInt(Prefs.ADJ_Y, 0).toFloat()))
        cx += dp(prefs.getInt(Prefs.ADJ_X, 0).toFloat())
        return Geo(cx, top, w, h)
    }

    private fun contentHeight(m: IslandMode): Float = when (m) {
        IslandMode.NOTIFICATION -> dp(62f)
        IslandMode.MEDIA -> dp(122f)
        IslandMode.CHARGING -> dp(46f)
        IslandMode.IDLE -> 0f
    }

    private fun targetWidth(m: IslandMode, g: Geo): Float = when (m) {
        IslandMode.NOTIFICATION, IslandMode.MEDIA -> min(screenW - dp(24f), dp(360f))
        IslandMode.CHARGING -> min(screenW - dp(24f), dp(230f))
        IslandMode.IDLE -> g.w
    }

    private fun applyGeometry(w: Float, h: Float, cx: Float, top: Float) {
        curW = w
        curH = h
        curCx = cx
        curTop = top
        val iw = max(1, w.roundToInt())
        lp.width = iw
        lp.height = max(1, h.roundToInt())
        lp.x = (cx - w / 2f).roundToInt().coerceIn(0, max(0, screenW - iw))
        lp.y = top.roundToInt()
        view.setCornerRadiusPx(min(min(w, h) / 2f, dp(34f)))
        if (attached) {
            try {
                wm.updateViewLayout(view, lp)
            } catch (_: Exception) {
            }
        }
    }

    /** Aplica o estado final do modo atual imediatamente (rotação, ajustes, mudança de tela). */
    private fun settle() {
        if (!attached) return
        animator?.cancel()
        updateScreen()
        val g = idleGeo()
        view.setContentTopPadding(g.h.roundToInt())
        view.showMode(mode)
        view.setContentAlpha(1f)
        if (mode == IslandMode.IDLE) {
            applyGeometry(g.w, g.h, g.cx, g.top)
        } else {
            applyGeometry(targetWidth(mode, g), g.h + contentHeight(mode), g.cx, g.top)
        }
        applyVisibility()
    }

    // --------------------------------------------------------------- animação

    private fun lerp(a: Float, b: Float, t: Float) = a + (b - a) * t

    private fun animateTo(
        g: Geo, tw: Float, th: Float, expanding: Boolean, fade: Boolean = true, end: (() -> Unit)? = null
    ) {
        animator?.cancel()
        val fw = curW
        val fh = curH
        val fcx = curCx
        val ftop = curTop
        val a = ValueAnimator.ofFloat(0f, 1f)
        a.duration = if (expanding) 420L else 320L
        a.interpolator = if (expanding) OvershootInterpolator(0.7f) else DecelerateInterpolator(1.8f)
        a.addUpdateListener { va ->
            val p = va.animatedValue as Float
            applyGeometry(lerp(fw, tw, p), lerp(fh, th, p), lerp(fcx, g.cx, p), lerp(ftop, g.top, p))
            val f = va.animatedFraction
            if (fade) {
                view.setContentAlpha(
                    if (expanding) ((f - 0.35f) / 0.45f).coerceIn(0f, 1f) else (1f - f * 2.2f).coerceIn(0f, 1f)
                )
            }
        }
        a.addListener(object : AnimatorListenerAdapter() {
            private var cancelled = false
            override fun onAnimationCancel(animation: Animator) {
                cancelled = true
            }

            override fun onAnimationEnd(animation: Animator) {
                if (!cancelled) end?.invoke()
            }
        })
        animator = a
        a.start()
    }

    // ----------------------------------------------------------------- estados

    private fun suppressed(): Boolean =
        prefs.getBoolean(Prefs.HIDE_LANDSCAPE, true) && screenW > screenH

    private fun active(): Boolean = attached && !suppressed()

    private fun idleVisible(): Boolean = prefs.getBoolean(Prefs.IDLE_PILL, true) || previewing

    private fun applyVisibility() {
        view.visibility = when {
            suppressed() -> View.GONE
            mode != IslandMode.IDLE || idleVisible() -> View.VISIBLE
            else -> View.INVISIBLE
        }
        updateTouchable()
    }

    private fun updateTouchable() {
        val interactive = !suppressed() &&
            (mode != IslandMode.IDLE || (lastMedia != null && idleVisible()))
        val f = if (interactive) {
            lp.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
        } else {
            lp.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        }
        if (f != lp.flags) {
            lp.flags = f
            if (attached) {
                try {
                    wm.updateViewLayout(view, lp)
                } catch (_: Exception) {
                }
            }
        }
    }

    private fun schedule(ms: Long) {
        main.removeCallbacks(collapseRunnable)
        autoMs = ms
        if (ms > 0) main.postDelayed(collapseRunnable, ms)
    }

    private fun enter(newMode: IslandMode, autoCollapseMs: Long) {
        if (!active() || newMode == IslandMode.IDLE) return
        val wasIdle = mode == IslandMode.IDLE
        mode = newMode
        updateScreen()
        val g = idleGeo()
        view.setContentTopPadding(g.h.roundToInt())
        view.showMode(newMode)
        if (wasIdle) view.setContentAlpha(0f)
        applyVisibility()
        animateTo(g, targetWidth(newMode, g), g.h + contentHeight(newMode), true, wasIdle) {
            view.setContentAlpha(1f)
        }
        schedule(autoCollapseMs)
    }

    private fun collapse() {
        main.removeCallbacks(collapseRunnable)
        autoMs = 0L
        if (mode == IslandMode.IDLE) return
        mode = IslandMode.IDLE
        updateTouchable()
        val g = idleGeo()
        animateTo(g, g.w, g.h, false, true) {
            view.showMode(IslandMode.IDLE)
            view.setContentAlpha(1f)
            applyVisibility()
        }
    }

    private fun haptic() {
        if (prefs.getBoolean(Prefs.HAPTIC, true)) {
            view.performHapticFeedback(HapticFeedbackConstants.CONTEXT_CLICK)
        }
    }

    private fun onPillClick() {
        when (mode) {
            IslandMode.IDLE -> if (lastMedia != null) {
                haptic()
                enter(IslandMode.MEDIA, 6000L)
            }
            IslandMode.NOTIFICATION -> {
                haptic()
                val n = currentNotification
                launch(n?.intent, n?.pkg)
                collapse()
            }
            IslandMode.MEDIA -> {
                haptic()
                val c = lastMedia?.controller
                launch(c?.sessionActivity, c?.packageName)
                collapse()
            }
            IslandMode.CHARGING -> collapse()
        }
    }

    private fun launch(pi: PendingIntent?, pkg: String?) {
        var ok = false
        if (pi != null) {
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                    val opts = ActivityOptions.makeBasic()
                        .setPendingIntentBackgroundActivityStartMode(
                            ActivityOptions.MODE_BACKGROUND_ACTIVITY_START_ALLOWED
                        )
                    pi.send(opts.toBundle())
                } else {
                    pi.send()
                }
                ok = true
            } catch (_: Exception) {
            }
        }
        if (!ok && pkg != null) {
            val i = ctx.packageManager.getLaunchIntentForPackage(pkg) ?: return
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            try {
                ctx.startActivity(i)
            } catch (_: Exception) {
            }
        }
    }

    // ------------------------------------------------------------------ eventos

    override fun onNotification(info: NotificationInfo) {
        if (!active() || !prefs.getBoolean(Prefs.SHOW_NOTIFICATIONS, true)) return
        currentNotification = info
        val hide = km.isKeyguardLocked && prefs.getBoolean(Prefs.HIDE_LOCKED, true)
        view.bindNotification(info, hide)
        enter(IslandMode.NOTIFICATION, 4500L)
    }

    override fun onMedia(info: MediaInfo?) {
        val prev = lastMedia
        lastMedia = info
        updateTouchable()
        if (info == null) {
            if (mode == IslandMode.MEDIA) collapse()
            return
        }
        view.bindMedia(info)
        if (!active() || !prefs.getBoolean(Prefs.SHOW_MEDIA, true)) return
        val changed = prev == null || prev.key != info.key
        val started = info.playing && prev?.playing != true
        if (info.playing && (changed || started) &&
            mode != IslandMode.NOTIFICATION && mode != IslandMode.MEDIA
        ) {
            enter(IslandMode.MEDIA, 5000L)
        }
    }

    private fun onPowerConnected() {
        if (!active() || !prefs.getBoolean(Prefs.SHOW_CHARGING, true)) return
        if (mode == IslandMode.NOTIFICATION || mode == IslandMode.MEDIA) return
        val b = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) ?: return
        val level = b.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = b.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
        if (level < 0 || scale <= 0) return
        view.bindCharging(level * 100 / scale)
        enter(IslandMode.CHARGING, 3200L)
    }

    private fun startPreview() {
        previewing = true
        main.removeCallbacks(previewEnd)
        main.postDelayed(previewEnd, 2500L)
    }

    override fun onSharedPreferenceChanged(sp: SharedPreferences?, key: String?) {
        if (key == null) return
        if (key == Prefs.ENABLED) {
            if (prefs.getBoolean(Prefs.ENABLED, true)) attach() else detach()
        } else if (key in Prefs.GEOMETRY_KEYS) {
            startPreview()
            settle()
        } else {
            settle()
        }
    }
}
