package com.novaisland.app.ui

import android.content.Context
import android.graphics.Color
import android.graphics.Outline
import android.graphics.PorterDuff
import android.graphics.drawable.GradientDrawable
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewOutlineProvider
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import com.novaisland.app.R
import com.novaisland.app.core.IslandMode
import com.novaisland.app.core.MediaInfo
import com.novaisland.app.core.NotificationInfo
import kotlin.math.abs
import kotlin.math.roundToInt

/** Pílula preta com três layouts de conteúdo (notificação, mídia, carregando). Sem XML, sem Compose. */
class IslandView(context: Context) : FrameLayout(context) {

    var onInteraction: (() -> Unit)? = null
    var onSwipeUp: (() -> Unit)? = null
    var onPrev: (() -> Unit)? = null
    var onPlayPause: (() -> Unit)? = null
    var onNext: (() -> Unit)? = null

    private val density = resources.displayMetrics.density
    private fun dp(v: Int) = (v * density).roundToInt()

    private val pillBg = GradientDrawable().apply { setColor(Color.BLACK) }
    private val content = FrameLayout(context)

    // Notificação
    private val notifRow = LinearLayout(context)
    private val notifIcon = ImageView(context)
    private val notifTitle = TextView(context)
    private val notifText = TextView(context)

    // Mídia
    private val mediaColumn = LinearLayout(context)
    private val mediaArt = ImageView(context)
    private val mediaTitle = TextView(context)
    private val mediaArtist = TextView(context)
    private val btnPrev = ImageView(context)
    private val btnPlay = ImageView(context)
    private val btnNext = ImageView(context)

    // Carregando
    private val chargeRow = LinearLayout(context)
    private val chargePct = TextView(context)

    private var downX = 0f
    private var downY = 0f

    init {
        setBackground(pillBg)
        clipToOutline = true
        isClickable = true

        addView(content, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT))
        content.setPadding(dp(16), 0, dp(16), dp(10))

        buildNotification()
        buildMedia()
        buildCharging()
        showMode(IslandMode.IDLE)
    }

    // ------------------------------------------------------------ construção

    private fun roundClip(v: View, radiusDp: Int) {
        v.clipToOutline = true
        v.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setRoundRect(0, 0, view.width, view.height, dp(radiusDp).toFloat())
            }
        }
    }

    private fun style(t: TextView, sp: Float, color: Int, bold: Boolean) {
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
        t.setTextColor(color)
        t.maxLines = 1
        t.ellipsize = TextUtils.TruncateAt.END
        if (bold) t.setTypeface(t.typeface, android.graphics.Typeface.BOLD)
    }

    private fun buildNotification() {
        notifRow.orientation = LinearLayout.HORIZONTAL
        notifRow.gravity = Gravity.CENTER_VERTICAL

        notifIcon.scaleType = ImageView.ScaleType.CENTER_CROP
        roundClip(notifIcon, 10)
        notifRow.addView(notifIcon, LinearLayout.LayoutParams(dp(40), dp(40)))

        val col = LinearLayout(context)
        col.orientation = LinearLayout.VERTICAL
        style(notifTitle, 15f, Color.WHITE, true)
        style(notifText, 13f, 0xB3FFFFFF.toInt(), false)
        col.addView(notifTitle)
        col.addView(notifText)
        val colLp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        colLp.marginStart = dp(12)
        notifRow.addView(col, colLp)

        content.addView(
            notifRow,
            LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT, Gravity.CENTER_VERTICAL)
        )
    }

    private fun control(v: ImageView, res: Int, desc: Int, click: () -> Unit) {
        v.setImageResource(res)
        v.contentDescription = context.getString(desc)
        v.setPadding(dp(10), dp(10), dp(10), dp(10))
        v.setColorFilter(Color.WHITE, PorterDuff.Mode.SRC_IN)
        v.setOnClickListener {
            click()
            onInteraction?.invoke()
        }
    }

    private fun buildMedia() {
        mediaColumn.orientation = LinearLayout.VERTICAL

        val top = LinearLayout(context)
        top.orientation = LinearLayout.HORIZONTAL
        top.gravity = Gravity.CENTER_VERTICAL

        mediaArt.scaleType = ImageView.ScaleType.CENTER_CROP
        mediaArt.setBackgroundColor(0xFF2A2A2E.toInt())
        roundClip(mediaArt, 10)
        top.addView(mediaArt, LinearLayout.LayoutParams(dp(48), dp(48)))

        val col = LinearLayout(context)
        col.orientation = LinearLayout.VERTICAL
        style(mediaTitle, 15f, Color.WHITE, true)
        style(mediaArtist, 13f, 0xB3FFFFFF.toInt(), false)
        col.addView(mediaTitle)
        col.addView(mediaArtist)
        val colLp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        colLp.marginStart = dp(12)
        top.addView(col, colLp)
        mediaColumn.addView(top, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(48)))

        val controls = LinearLayout(context)
        controls.orientation = LinearLayout.HORIZONTAL
        controls.gravity = Gravity.CENTER
        control(btnPrev, R.drawable.ic_prev, R.string.prev) { onPrev?.invoke() }
        control(btnPlay, R.drawable.ic_pause, R.string.play_pause) { onPlayPause?.invoke() }
        control(btnNext, R.drawable.ic_next, R.string.next) { onNext?.invoke() }
        for (b in listOf(btnPrev, btnPlay, btnNext)) {
            val lp = LinearLayout.LayoutParams(dp(48), dp(44))
            lp.marginStart = dp(16)
            lp.marginEnd = dp(16)
            controls.addView(b, lp)
        }
        val ctlLp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(44))
        ctlLp.topMargin = dp(10)
        mediaColumn.addView(controls, ctlLp)

        content.addView(
            mediaColumn,
            LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT, Gravity.CENTER_VERTICAL)
        )
    }

    private fun buildCharging() {
        chargeRow.orientation = LinearLayout.HORIZONTAL
        chargeRow.gravity = Gravity.CENTER

        val bolt = ImageView(context)
        bolt.setImageResource(R.drawable.ic_bolt)
        bolt.setColorFilter(0xFF34C759.toInt(), PorterDuff.Mode.SRC_IN)
        chargeRow.addView(bolt, LinearLayout.LayoutParams(dp(20), dp(20)))

        val label = TextView(context)
        label.setText(R.string.charging)
        style(label, 14f, Color.WHITE, true)
        val labelLp = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT
        )
        labelLp.marginStart = dp(8)
        chargeRow.addView(label, labelLp)

        style(chargePct, 14f, 0xFF34C759.toInt(), true)
        val pctLp = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT
        )
        pctLp.marginStart = dp(8)
        chargeRow.addView(chargePct, pctLp)

        content.addView(
            chargeRow,
            LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT, Gravity.CENTER_VERTICAL)
        )
    }

    // ------------------------------------------------------------------- API

    fun showMode(mode: IslandMode) {
        notifRow.visibility = if (mode == IslandMode.NOTIFICATION) VISIBLE else GONE
        mediaColumn.visibility = if (mode == IslandMode.MEDIA) VISIBLE else GONE
        chargeRow.visibility = if (mode == IslandMode.CHARGING) VISIBLE else GONE
        content.visibility = if (mode == IslandMode.IDLE) INVISIBLE else VISIBLE
    }

    /** Espaço reservado no topo para que o conteúdo fique abaixo do furo da câmera. */
    fun setContentTopPadding(px: Int) {
        content.setPadding(dp(16), px, dp(16), dp(10))
    }

    fun setContentAlpha(a: Float) {
        content.alpha = a
    }

    fun setCornerRadiusPx(px: Float) {
        pillBg.cornerRadius = px
        invalidateOutline()
    }

    fun bindNotification(info: NotificationInfo, hideContent: Boolean) {
        notifIcon.setImageDrawable(info.icon)
        if (hideContent) {
            notifTitle.text = info.appName
            notifText.text = context.getString(R.string.locked_notification)
        } else {
            notifTitle.text = info.title.ifBlank { info.appName }
            notifText.text = info.text
        }
        notifText.visibility = if (notifText.text.isNullOrBlank()) GONE else VISIBLE
    }

    fun bindMedia(info: MediaInfo) {
        mediaTitle.text = info.title
        mediaArtist.text = info.artist
        mediaArtist.visibility = if (info.artist.isBlank()) GONE else VISIBLE
        mediaArt.setImageBitmap(info.art)
        btnPlay.setImageResource(if (info.playing) R.drawable.ic_pause else R.drawable.ic_play)
        btnPlay.setColorFilter(Color.WHITE, PorterDuff.Mode.SRC_IN)
    }

    fun bindCharging(percent: Int) {
        chargePct.text = "$percent%"
    }

    // ------------------------------------------------------------ gestos

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = ev.rawX
                downY = ev.rawY
                onInteraction?.invoke()
            }
            MotionEvent.ACTION_UP -> {
                val dy = ev.rawY - downY
                val dx = ev.rawX - downX
                if (dy < -dp(28) && abs(dy) > abs(dx)) {
                    // Cancela o clique que um filho poderia receber e trata como deslize para cima.
                    val cancel = MotionEvent.obtain(ev)
                    cancel.action = MotionEvent.ACTION_CANCEL
                    super.dispatchTouchEvent(cancel)
                    cancel.recycle()
                    onSwipeUp?.invoke()
                    return true
                }
            }
        }
        return super.dispatchTouchEvent(ev)
    }
}
